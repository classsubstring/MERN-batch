document
  .getElementById("contact_form")
  .addEventListener("submit", function (event) {
    event.preventDefault();
    console.log("form submitted");

    //validate all fields

    const nameValue = document.getElementById("user_name").value;
    const emailValue = document.getElementById("user_email").value;
    const messageValue = document.getElementById("user_message").value;
    // console.log(nameValue);
    // console.log(emailValue);
    // console.log(messageValue);
    let errors = [];

    // if (nameValue.trim() == "") {
    //   errors.push("Name is required !!");
    // }

    if (!/^(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{3,7}$/.test(nameValue)) {
      errors.push(
        "Username must be between 2 and 8 characters long. Username must contain at least one digit. Username must contain at least one special character (!@#$%^&*)."
      );
    }

    // if (emailValue.trim() == "") {
    //   errors.push("Email is required !!");
    // }
    // if (!emailValue.includes("@")) {
    //   errors.push("Invalid Email !! ");
    // }
    if (!/^[^s@]+@[^s@]+.[^s@]+$/.test(emailValue)) {
      errors.push("Email invalid. Write in this format [abc@gmail.com]");
    }

    if (messageValue.trim() == "") {
      errors.push("Message is required !!");
    }

    if (errors.length > 0) {
      //error
      const errorsDiv = document.getElementById("errors");
      errorsDiv.innerHTML = "";

      for (const error of errors) {
        errorsDiv.innerHTML =
          errorsDiv.innerHTML +
          `<p class='mt-2 border p-2 rounded-2xl border-red-300 '>  ${error} </p>`;
      }

      errorsDiv.classList.remove("hidden");
    } else {
      this.submit();
    }
  });
