export default function Footer() {
  return <h1>This is footer</h1>;
}
