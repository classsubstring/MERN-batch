export default function ListExpenses() {
  return (
    <div>
      <h1>All expenses are here:</h1>
      <ul>
        <li>Iphone</li>
        <li>Charger</li>
        <li>MBW</li>
      </ul>
    </div>
  );
}
